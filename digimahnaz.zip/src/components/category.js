let categorycontainer = document.querySelector(".category");
let category = async () => {
  let data = await fetch("http://localhost:3000/category");
  let res = await data.json();
  res.map((category) => {
    let item = `<swiper-slide class="flex flex-col gap-3 !w-[110px] *:flex *:items-center *:gap-3"><div><img class="w-[90px]" src="${category[0].image}"/><p>${category[0].title}</p>></div>
    <div><img class="w-[90px]" src="${category[1].image}"/><p>${category[1].title}</p></div>
        <div><img class="w-[90px]" src="${category[2].image}"/><p>${category[2].title}</p></div></swiper-slide>`;

    categorycontainer?.insertAdjacentHTML("beforeend", item);
  });
};
export default category;
